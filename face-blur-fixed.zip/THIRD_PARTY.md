# Сторонние компоненты

## Модель YuNet — `data/models/face_detection_yunet_640x480.onnx`

Лёгкая модель детекции лиц YuNet (проект libfacedetection). Файл взят из репозитория depthai_yunet (`models/build/face_detection_yunet.onnx`).
Лицензия этого репозитория — MIT, copyright 2021 geax — см. `third_party/depthai_yunet-LICENSE.txt`.
Лицензию исходной модели смотрите в апстриме YuNet / libfacedetection.

Формат модели: три выхода `loc`, `conf`, `iou`. Декодирование якорей — в `src/yunet-detector.hpp`,
эталонная реализация на Python — в `tests/yunet_reference.py`.

## OpenCV

Используются модули `core`, `imgproc`, `dnn` (Apache-2.0).

Файл в репозитории — тот же YuNet, но с зафиксированным входом 1x3x480x640 (в оригинале размеры входа динамические, что не поддерживает OpenCV 4.13). Веса не менялись; выходы совпадают с оригиналом (макс. расхождение ~1e-5).
